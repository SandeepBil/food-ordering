const express=require('express');
const app=express();

app.get('/Login',(req,res)=>{
    res.sendFile(`${publicpath}/login.html`)
    
})