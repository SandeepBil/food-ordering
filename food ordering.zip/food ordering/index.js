const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const con = require('./DB_Conn.js');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

const publicpath = path.join(__dirname, 'public');

// Uncomment if you want to serve static files from the 'public' directory
// app.use(express.static(publicpath));

// Root route
app.get('/', (req, res) => {
    res.send('Welcome to the Home Page!');
});

// Route for Index
app.get('/Index', (req, res) => {
    res.sendFile(`${publicpath}/index.html`);
});

// Route for Login
app.get('/Login', (req, res) => {
    res.sendFile(`${publicpath}/login1.html`);
});

// Route for Register
app.get('/Register', (req, res) => {
    res.sendFile(`${publicpath}/registration.html`);
});

// Handle Registration Validation
app.post('/Registrationvalidation', (req, res) => {
    const user = req.body.register_username;
    const pass = req.body.register_password;
    const cpass = req.body.confirm_password;
    const sql = `INSERT INTO sandeep(register_username,register_password,confirm_password) VALUES('${user}','${pass}','${cpass}')`;
    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Data inserted successfully");
        res.redirect('/Login');
    });
});

// Handle Login Validation
app.post('/LoginValidation', (req, res) => {
    const luser = req.body.login_username;
    const lpassd = req.body.login_password;
    const sql = `SELECT * FROM sandeep WHERE register_username =${con.escape(luser)} AND register_password=${con.escape(lpassd)}`;
    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log(result.length);
        if (result.length > 0) {
            console.log("Login success");
            res.sendFile(`${publicpath}/index.html`);
        } else {
            res.send('Login failed. Invalid username or password.');
        }
    });
});

// 404 Page Not Found route
app.get('*', (req, res) => {
    res.sendFile(`${publicpath}/Pagenotfound.html`);
});

// Start the server
app.listen(3002, () => {
    console.log('Server is running on http://localhost:3002');
});
